/*****************************************************************************
 * NeonTheme.kt
 *****************************************************************************
 * Neon Style Studio: runtime accent / font / glass selection and player look.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *****************************************************************************/

package org.videolan.vlc.gui.helpers

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.View
import androidx.annotation.AttrRes
import androidx.core.content.ContextCompat
import org.videolan.tools.KEY_APP_THEME
import org.videolan.tools.Settings
import org.videolan.vlc.R

/**
 * Applies the user selected accent colour, font and glass strength as theme overlays
 * (see res/values/neon_themes.xml) and styles the video player controls.
 */
object NeonTheme {
    const val KEY_ACCENT = "neon_accent"
    const val KEY_FONT = "neon_font"
    const val KEY_GLASS = "neon_glass"
    const val KEY_PLAYER_GLASS_BUTTONS = "neon_player_glass_buttons"
    const val KEY_PLAYER_CONTROLS_SIZE = "neon_player_controls_size"
    const val KEY_PLAYER_SCRIM = "neon_player_scrim"
    const val KEY_PLAYER_BUTTON_SHAPE = "neon_player_button_shape"
    const val KEY_PLAYER_HIDDEN = "neon_player_hidden"

    /** Ids stored in KEY_PLAYER_HIDDEN, same values as R.array.neon_hidden_values. */
    const val HIDE_TRACKS = "tracks"
    const val HIDE_ORIENTATION = "orientation"
    const val HIDE_RESIZE = "resize"
    const val HIDE_ADVANCED = "advanced"
    const val HIDE_PREV_NEXT = "prev_next"
    const val HIDE_TIME = "time"
    const val HIDE_LENGTH = "length"

    /** Keys that need an app restart to be fully applied. */
    val THEME_KEYS = setOf(KEY_ACCENT, KEY_FONT, KEY_GLASS)

    /** Preview colours for the accent picker, same order as R.array.neon_accent_values. */
    val ACCENT_PREVIEW = intArrayOf(
        0xFF00E5FF.toInt(), 0xFFA855F7.toInt(), 0xFF3D7BFF.toInt(), 0xFFFF2BD6.toInt(), 0xFF00E58F.toInt(),
        0xFFFF6B4A.toInt(), 0xFFFFB800.toInt(), 0xFFFF3B5C.toInt(), 0xFFD6E4F0.toInt()
    )

    /** Call before super.onCreate() of an activity so layouts inflate with the selected style. */
    @JvmStatic
    fun apply(activity: Activity) {
        val prefs = Settings.getInstance(activity)
        val theme = activity.theme
        theme.applyStyle(accentStyle(prefs.getString(KEY_ACCENT, "cyan")), true)
        fontStyle(prefs.getString(KEY_FONT, "system"))?.let { theme.applyStyle(it, true) }
        // The glass overlay is dark glass: only use it when the app is in a dark theme.
        if (isDark(activity, prefs)) theme.applyStyle(glassStyle(prefs.getString(KEY_GLASS, "balanced")), true)
    }

    private fun isDark(activity: Activity, prefs: SharedPreferences): Boolean = when (prefs.getString(KEY_APP_THEME, "2")) {
        "2" -> true
        "1" -> false
        else -> (activity.applicationContext.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun accentStyle(id: String?): Int = when (id) {
        "purple" -> R.style.ThemeOverlay_Neon_Accent_Purple
        "blue" -> R.style.ThemeOverlay_Neon_Accent_Blue
        "magenta" -> R.style.ThemeOverlay_Neon_Accent_Magenta
        "emerald" -> R.style.ThemeOverlay_Neon_Accent_Emerald
        "sunset" -> R.style.ThemeOverlay_Neon_Accent_Sunset
        "gold" -> R.style.ThemeOverlay_Neon_Accent_Gold
        "crimson" -> R.style.ThemeOverlay_Neon_Accent_Crimson
        "silver" -> R.style.ThemeOverlay_Neon_Accent_Silver
        else -> R.style.ThemeOverlay_Neon_Accent_Cyan
    }

    private fun fontStyle(id: String?): Int? = when (id) {
        "outfit" -> R.style.ThemeOverlay_Neon_Font_Outfit
        "tektur" -> R.style.ThemeOverlay_Neon_Font_Tektur
        "jura" -> R.style.ThemeOverlay_Neon_Font_Jura
        "instrument" -> R.style.ThemeOverlay_Neon_Font_Instrument
        "bricolage" -> R.style.ThemeOverlay_Neon_Font_Bricolage
        "poiret" -> R.style.ThemeOverlay_Neon_Font_Poiret
        "mono" -> R.style.ThemeOverlay_Neon_Font_Mono
        "lora" -> R.style.ThemeOverlay_Neon_Font_Lora
        "pixel" -> R.style.ThemeOverlay_Neon_Font_Pixel
        else -> null
    }

    private fun glassStyle(id: String?): Int = when (id) {
        "subtle" -> R.style.ThemeOverlay_Neon_Glass_Subtle
        "frosted" -> R.style.ThemeOverlay_Neon_Glass_Frosted
        else -> R.style.ThemeOverlay_Neon_Glass_Balanced
    }

    /** Label with a coloured dot in front, used by the accent picker. */
    fun coloredEntry(label: CharSequence, color: Int): CharSequence {
        val s = SpannableString("\u25CF  $label")
        s.setSpan(ForegroundColorSpan(color), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return s
    }

    /**
     * Applies the player customisation (glass buttons, control size, overlay shade).
     * Called once the video HUD is bound, so it only affects the UI, never playback.
     */
    fun stylePlayerControls(prefs: SharedPreferences, controls: List<View?>, scrims: List<View?>) {
        val glass = prefs.getBoolean(KEY_PLAYER_GLASS_BUTTONS, true)
        val shape = if (prefs.getString(KEY_PLAYER_BUTTON_SHAPE, "circle") == "rounded") R.drawable.neon_glass_square_ripple
        else R.drawable.neon_glass_circle_ripple
        val scale = when (prefs.getString(KEY_PLAYER_CONTROLS_SIZE, "normal")) {
            "small" -> 0.85f
            "large" -> 1.2f
            else -> 1f
        }
        controls.forEach { v ->
            if (v == null) return@forEach
            if (glass) {
                v.setBackgroundResource(shape)
                val pad = (v.resources.displayMetrics.density * 10).toInt()
                v.setPadding(pad, pad, pad, pad)
            }
            v.scaleX = scale
            v.scaleY = scale
        }
        val alpha = when (prefs.getString(KEY_PLAYER_SCRIM, "medium")) {
            "light" -> 110
            "strong" -> 255
            else -> 190
        }
        scrims.forEach { it?.background?.mutate()?.setAlpha(alpha) }
    }

    /**
     * Hides the player controls the user switched off in Neon Style Studio.
     * Must be called each time the HUD updates its own visibilities (VideoPlayerOverlayDelegate.showControls).
     * The play button and the seek bar are never hidden.
     */
    fun applyPlayerVisibility(prefs: SharedPreferences, groups: Map<String, List<View?>>) {
        val hidden: Set<String> = prefs.getStringSet(KEY_PLAYER_HIDDEN, emptySet()) ?: emptySet()
        if (hidden.isEmpty()) return
        groups.forEach { (id, views) ->
            if (hidden.contains(id)) views.forEach { it?.visibility = View.GONE }
        }
    }
}

/** Resolves a theme attribute holding a colour (see neonAccent* attributes). */
fun Context.neonColor(@AttrRes attr: Int): Int {
    val tv = TypedValue()
    if (!theme.resolveAttribute(attr, tv, true)) return ContextCompat.getColor(this, R.color.neon_cyan)
    return if (tv.type >= TypedValue.TYPE_FIRST_COLOR_INT && tv.type <= TypedValue.TYPE_LAST_COLOR_INT) tv.data
    else ContextCompat.getColor(this, tv.resourceId)
}
