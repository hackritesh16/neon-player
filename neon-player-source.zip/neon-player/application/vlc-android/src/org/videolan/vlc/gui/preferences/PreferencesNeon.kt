/*****************************************************************************
 * PreferencesNeon.kt
 *****************************************************************************
 * Neon Style Studio settings screen.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *****************************************************************************/

package org.videolan.vlc.gui.preferences

import android.content.SharedPreferences
import android.os.Bundle
import androidx.preference.ListPreference
import org.videolan.vlc.R
import org.videolan.vlc.gui.helpers.NeonTheme
import org.videolan.vlc.gui.helpers.UiTools

class PreferencesNeon : BasePreferenceFragment(), SharedPreferences.OnSharedPreferenceChangeListener {

    override fun getXml() = R.xml.preferences_neon

    override fun getTitleId() = R.string.neon_style_title

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Show a coloured dot in front of every accent so the choice is visual.
        findPreference<ListPreference>(NeonTheme.KEY_ACCENT)?.let { pref ->
            val labels = resources.getStringArray(R.array.neon_accent_entries)
            pref.entries = Array<CharSequence>(labels.size) { i ->
                NeonTheme.coloredEntry(labels[i], NeonTheme.ACCENT_PREVIEW[i])
            }
        }
    }

    override fun onStart() {
        super.onStart()
        preferenceScreen.sharedPreferences!!.registerOnSharedPreferenceChangeListener(this)
    }

    override fun onStop() {
        super.onStop()
        preferenceScreen.sharedPreferences!!.unregisterOnSharedPreferenceChangeListener(this)
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        if (key == null || !NeonTheme.THEME_KEYS.contains(key)) return
        // Accent, font and glass are theme overlays: they apply to every screen after a restart.
        UiTools.restartDialog(requireActivity())
    }
}
